const help = (prefix, pushname) => {
	return `✪═⟪ 𝑹𝒀𝑶𝑩𝑶𝑻 𝑴𝑬𝑵𝑼 ⟫═✪

*AUTHOR : 𝐑𝐘𝐎𝐍𝐄*
*BOT TYPE : 𝐓𝐄𝐑𝐌𝐔𝐗*:v

╔════════════════════
║ Hai Bor and Sis :v
╠════════════════════
║╭──❉ 𝑰𝒏𝒇𝒐 ❉──
║│1. ${prefix}info
║│2. ${prefix}bugreport <lapor bug>
║│3. ${prefix}runtime
║│4. ${prefix}join <linkgroup>
║╰───────────
║╭──❉ 𝑮𝑹𝑶𝑼𝑷 𝑴𝑬𝑵𝑼 ❉──
║│1. ${prefix}clone
║│2. ${prefix}promote <@tagmember>
║│3. ${prefix}demote <@tagadmin>
║│4. ${prefix}tagall <1 atau 2 atau 3>
║│5. ${prefix}simih <0 atau 1>
║│6. ${prefix}group <open atau close>
║│8. ${prefix}setdesc <teks>
║│9. ${prefix}setpp 
║│10. ${prefix}setname <teks>
║│11. ${prefix}kick <@tagmember>
║│12. ${prefix}linkgroup
║│13. ${prefix}add <nomor>
║│14. ${prefix}welcome <enable/disable>
║╰───────────
║╭──❉ 𝑴𝑬𝑫𝑰𝑨 ❉──
║│1. ${prefix}toimg <reply stiker>
║│2. ${prefix}sticker
║│3. ${prefix}ttp <teks>
║│4. ${prefix}sticker nobg <ERROR>
║│5. ${prefix}tts <kode bahasa> <teks>
║│6. ${prefix}url2img <tipe> <url>
║│7. ${prefix}wait <kirim atau reply foto>
║│8. ${prefix}ocr
║│9. ${prefix}nulis <teks>
║╰───────────
║╭──❉ 𝑶𝑾𝑵𝑬𝑹 𝑴𝑬𝑵𝑼 ❉──
║│1. ${prefix}setprefix <prefix>
║│2. ${prefix}bc <promosi>
║│3. ${prefix}setppbot 
║│4. ${prefix}clone @tagmember
║╰───────────
║╭──❉ 𝑭𝑼𝑵 ❉──
║│1. ${prefix}truth
║│2. ${prefix}dare
║│3. ${prefix}apakah
║│4. ${prefix}bolehkah
║│5. ${prefix}kapan
║│6. ${prefix}rate
║╰───────────
║╭──❉ 𝐏𝐄𝐒𝐀𝐍 ❉──
║│*Sebenarnya ada beberapa fitur lain*
║│*tapi mager buat di tulis di menu:v*
║╰───────────
║╭──❉ 𝐈𝐊𝐋𝐀𝐍 ❉──
║│1. instagram
║│ @ff.ryone
║│2. Creator RyoBot
║│ https://wa.me/6282157581762
║╰───────────
║╭──❉ 𝐏𝐄𝐑𝐀𝐓𝐔𝐑𝐀𝐍 ❉──
║│1. JANGAN NELPON
║│2. JANGAN SPAM
║╰───────────
╠════════════════════
║                      𝑬𝑵𝑫
╚════════════════════`
}

exports.help = help

# Bot Whatsapp Versi Termux
1. Punya Hp
2. Download Termux Di Play Store / App Store
3. Cewek Buat Nemenin
4. Kopi Rokok
5. Paket Internet Mencukupi + Sinyal Lancar

# Jalankan Script Di Termux
1. $ termux-setup-storage [enter]
Izinkan Penyimpanan Untuk Termux 

# Next
2. $ pkg update -y && pkg upgrade -y [enter]
3. $ pkg install ffmpeg -y [enter]
4. $ pkg install wget -y [enter]
5. $ pkg install git -y [enter]
6. $ pkg install nodejs -y [enter]
7. $ pkg install tesseract [enter]
8. $ git clone https://githubcom/rafiadichandra0101/BotWAChan_ [enter]
9. $ ls  [enter]
10. $ cd BotWAChan_ [enter]
11. $ npm i -g cwebp [enter]
12. $ npm i node-tesseract-ocr [enter]
13. $ npm i -g ytdl [enter]
14. $ npm i [enter]
15. $ npm i got [enter]
Jika Terjadi Erorr, Silahkan Ulangi Kembali Perintahnya!

Atau $ bash install.sh  [enter]
Install Sekaligus Tanpa Mengetik Perintah Diatas
# Mulai
$ node index.js [enter]
Atau $ npm start  [enter]
Scan QR Code Di Whatsapp  Yang Ingin Kamu Jadikan BOT
~ Selesai
# Peringatan!
Jalankan Perintah Tanpa Tanda '$' 
